product_name = input("상품명: ")
price_text = input("단가(숫자만): ")
print("입력 자료형:", type(price_text))
price = int(price_text)  # 숫자 문자열을 정수로 바꿉니다.
quantity = int(input("수량(정수): "))
discount_rate = float(input("할인율(%): "))
subtotal = price * quantity
total = subtotal * (1 - discount_rate / 100)
print(f"{product_name} {quantity}개 / 결제액 {total:,.0f}원")
